# nlp-to-sql

| Initial Screen |
|-|
| ![](https://github.com/multiverseweb/nlp-to-sql/blob/main/documentation/images/init.png?raw=true) |

<details>
<summary>View More</summary>
  
| Database Connected |
|-|
| ![](https://github.com/multiverseweb/nlp-to-sql/blob/main/documentation/images/success.png?raw=true) |

| Connection Failure |
|-|
| ![](https://github.com/multiverseweb/nlp-to-sql/blob/main/documentation/images/failure.png?raw=true) |
